# EstudoHub v5.1

Versão completa (todos os tipos + botão editar funcionando).